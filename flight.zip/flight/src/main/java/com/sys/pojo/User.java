package com.sys.pojo;

/**
 * 用户实体类
 *
 */
public class User {
	private int uid;//编号
	private String username;//用户名
	private String password;//密码
	private String cardid;
	private String usex;//性别
	private String nickname;//昵称
	
	public User() {
		super();
	}
	public String getCardid() {
		return cardid;
	}
	public void setCardid(String cardid) {
		this.cardid = cardid;
	}
	public User(int uid, String username, String password, String usex, String nickname) {
		this.uid = uid;
		this.username = username;
		this.password = password;
		this.usex = usex;
		this.nickname = nickname;
	}

	public User(String username, String nickname) {
		super();
		this.username = username;
		this.nickname = nickname;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsex() {
		return usex;
	}
	public void setUsex(String usex) {
		this.usex = usex;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", username=" + username + ", password=" + password + ", cardid=" + cardid
				+ ", usex=" + usex + ", nickname=" + nickname + "]";
	}
	
	
}
