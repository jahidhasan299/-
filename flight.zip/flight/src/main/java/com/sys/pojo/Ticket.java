package com.sys.pojo;

public class Ticket {
	public int fid;
	public String username;
	public String location;
	public String destination;
	public String flighttime;
	public String flighttime1;
	public double price;
	public int seat;
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat = seat;
	}
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getFlighttime() {
		return flighttime;
	}
	public void setFlighttime(String flighttime) {
		this.flighttime = flighttime;
	}
	public String getFlighttime1() {
		return flighttime1;
	}
	public void setFlighttime1(String flighttime1) {
		this.flighttime1 = flighttime1;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Ticket [fid=" + fid + ", username=" + username + ", location=" + location + ", destination="
				+ destination + ", flighttime=" + flighttime + ", flighttime1=" + flighttime1 + ", price=" + price
				+ ", seat=" + seat + "]";
	}
	
}
