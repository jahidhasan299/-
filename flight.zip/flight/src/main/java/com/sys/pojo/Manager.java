package com.sys.pojo;

public class Manager {
	private int mid;//编号
	private String managername;//用户名
	private String password;//密码
	private String cardid;
	private String msex;//性别
	public int getMid() {
		return mid;
	}
	@Override
	public String toString() {
		return "Manager [mid=" + mid + ", managername=" + managername + ", password=" + password + ", cardid=" + cardid
				+ ", msex=" + msex + ", nickname=" + nickname + "]";
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getManagername() {
		return managername;
	}
	public void setManagername(String managername) {
		this.managername = managername;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCardid() {
		return cardid;
	}
	public void setCardid(String cardid) {
		this.cardid = cardid;
	}
	public String getMsex() {
		return msex;
	}
	public void setMsex(String msex) {
		this.msex = msex;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	private String nickname;//昵称
}
