package com.sys.pojo;

public class Flight {
public int fid;
public String location;
public String destination;
public String flighttime;
public String flighttime1;
public double price;
public int ticketnum;
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getTicketnum() {
	return ticketnum;
}
public void setTicketnum(int ticketnum) {
	this.ticketnum = ticketnum;
}
public String getFlighttime1() {
	return flighttime1;
}
public void setFlighttime1(String flighttime1) {
	this.flighttime1 = flighttime1;
}
@Override
public String toString() {
	return "Flight [fid=" + fid + ", location=" + location + ", destination=" + destination + ", flighttime="
			+ flighttime + ", flighttime1=" + flighttime1 + ", price=" + price + ", ticketnum=" + ticketnum + "]";
}
public int getFid() {
	return fid;
}
public void setFid(int fid) {
	this.fid = fid;
}
public String getFlighttime() {
	return flighttime;
}
public void setFlighttime(String flighttime) {
	this.flighttime = flighttime;
}
}
