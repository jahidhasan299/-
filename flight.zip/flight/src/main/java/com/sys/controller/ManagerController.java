package com.sys.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sys.pojo.Manager;
import com.sys.service.ManagerService;
@Controller
public class ManagerController {
	@Autowired
	private ManagerService managerService;
	@RequestMapping("/getManager")
	@ResponseBody
	public boolean getManager(Manager manager){
		boolean flag = false;
		String managername = manager.getManagername();
		String password = manager.getPassword();
		try {
			Manager manager1 = managerService.getManager(managername);
			String password1 = manager1.getPassword();
			if(password1!=null && password1.equals(password)){
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/updateManager")
	@ResponseBody
	public boolean updateManager(Manager manager){
		boolean flag = false;
		try {
			 flag = managerService.updateManager(manager);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/getPasswordM")
	@ResponseBody
	public Manager getPasswordM(String managername,String cardid){
		Manager manager = new Manager();
		try {
			manager = managerService.getPasswordM(managername,cardid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return manager;
	}
}
