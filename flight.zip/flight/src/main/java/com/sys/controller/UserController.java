package com.sys.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sys.pojo.User;
import com.sys.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("/addUser")
	@ResponseBody
	public boolean addUser(User user){
		boolean flag = true;
		try {
			flag = userService.addUser(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	@RequestMapping("/getUser")
	@ResponseBody
	public boolean getUser(User user){
		boolean flag = false;
		String username = user.getUsername();
		String password = user.getPassword();
		try {
			User user1 = userService.getUser(username);
			String password1 = user1.getPassword();
			if(password1!=null && password1.equals(password)){
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	@RequestMapping("/deleteUser")
	@ResponseBody
	public boolean deleteUser(Integer uid){
		boolean flag = false;
		try {
			flag = userService.deleteUser(uid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/updateUser")
	@ResponseBody
	public boolean updateUser(User user){
		boolean flag = false;
		try {
			 flag = userService.updateUser(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@RequestMapping("/getUserByName")
	@ResponseBody
	public boolean getUserByName(String username){
		User user = new User();
		boolean flag=false;
		try {
			user = userService.getUserByName(username);
			if(user==null){
				flag=true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/getUserByCardid")
	@ResponseBody
	public User getUserByCardid(String cardid){
		User user = new User();
		try {
			user = userService.getUserByCardid(cardid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	@RequestMapping("/getPassword")
	@ResponseBody
	public User getPassword(String username,String cardid){
		User user = new User();
		try {
			user = userService.getPassword(username,cardid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
}
