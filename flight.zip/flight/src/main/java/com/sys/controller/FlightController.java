package com.sys.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sys.pojo.Flight;
import com.sys.service.FlightService;

@Controller
public class FlightController {
	@Autowired
	private FlightService flightService;
	@RequestMapping("/addFlight")
	@ResponseBody
	public boolean addFlight(Flight flight){
		boolean flag = true;
		try {
			flag = flightService.addFlight(flight);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/getFlight")
	@ResponseBody
	public List<Flight> getFlight(Flight flight){
		List<Flight> list = new ArrayList<Flight>();
		try {
			list = flightService.getFlight();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	@RequestMapping("/deleteFlight")
	@ResponseBody
	public boolean deleteFlight(Integer fid){
		boolean flag = false;
		try {
			flag = flightService.deleteFlight(fid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/getFlightByPlace")
	@ResponseBody
	public List<Flight> getFlightByPlace(String location,String destination){
		List<Flight> list = new ArrayList<Flight>();
		try {
			list = flightService.getFlightByPlace(location,destination);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	@RequestMapping("/buyTicket")
	@ResponseBody
	public boolean buyTicket(Integer fid){
		boolean flag = true;
		try {
			flag = flightService.buyTicket(fid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/getFlightByDestination")
	@ResponseBody
	public List<Flight> getFlightByDestination(String destination){
		List<Flight> list = new ArrayList<Flight>();
		try {
			list = flightService.getFlightByDestination(destination);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}

