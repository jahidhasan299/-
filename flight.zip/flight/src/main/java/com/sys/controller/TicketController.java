package com.sys.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sys.pojo.Ticket;
import com.sys.service.TicketService;
@Controller
public class TicketController {
	@Autowired
	private TicketService ticketService;
	@RequestMapping("/Ticket")
	@ResponseBody
	public boolean Ticket(Ticket ticket){
		boolean flag = true;
		try {
			flag = ticketService.Ticket(ticket);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@RequestMapping("/getTicketByUsername")
	@ResponseBody
		public List<Ticket> getTicketByUsername(String username){
		List<Ticket> ticket= new ArrayList<Ticket>();
			try {
				ticket = ticketService.getTicketByUsername(username);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ticket;
		}
	@RequestMapping("/delTicketById")
	@ResponseBody
	public boolean delTicketById(Integer fid){
		boolean flag = false;
		try {
			flag = ticketService.delTicketById(fid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
