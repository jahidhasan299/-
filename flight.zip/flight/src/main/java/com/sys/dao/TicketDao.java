package com.sys.dao;

import java.sql.SQLException;
import java.util.List;

import com.sys.pojo.Ticket;

public interface TicketDao {
	public int Ticket(Ticket ticket) throws SQLException;
	public List<Ticket> getTicketByUsername(String username) throws SQLException;
	public int delTicketById(int fid) throws SQLException;
}
