package com.sys.dao;

import java.sql.SQLException;
import java.util.List;

import com.sys.pojo.Flight;

public interface FlightDao {
	public int addFlight(Flight flight) throws SQLException;
	public  List<Flight> getFlight() throws SQLException;
	public int deleteFlight(int fid) throws SQLException;
	public List<Flight> getFlightByPlace(String location ,String destination) throws SQLException;
	public int buyTicket(int fid) throws SQLException;
	public List<Flight> getFlightByDestination(String destination) throws SQLException;
	}

