package com.sys.dao;

import java.sql.SQLException;
import com.sys.pojo.User;

public interface UserDao {
	//添加新用户
	public int addUser(User user) throws SQLException;
	//用户登录
	public User getUser(String username) throws SQLException;
	//删除用户
	public int deleteUser(int uid) throws SQLException;
	//根据用户名修改用户
    public int updateUser(User user) throws SQLException;
	public User getUserByCardid(String cardid) throws SQLException;
	public User getUserByName(String username)throws SQLException;
	public User getPassword(String username,String cardid) throws SQLException;
}
