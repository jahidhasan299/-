package com.sys.dao;

import java.sql.SQLException;

import com.sys.pojo.Manager;

public interface ManagerDao {
	public Manager getManager(String managername) throws SQLException;
	public int updateManager(Manager manager) throws SQLException;
	public Manager getPasswordM(String managername,String cardid) throws SQLException;
	
}
