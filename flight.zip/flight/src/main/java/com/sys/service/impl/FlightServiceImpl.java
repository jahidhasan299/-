package com.sys.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sys.dao.FlightDao;
import com.sys.pojo.Flight;
import com.sys.service.FlightService;
@Service
public class FlightServiceImpl implements FlightService{
@Autowired
private FlightDao flightDao;
	public boolean addFlight(Flight flight) throws Exception {
		boolean flag=true;
		int num=flightDao.addFlight(flight);
		if(num!=1){
			flag=false;
		}
		return flag;
	}
	public List<Flight> getFlight() throws Exception {
		List<Flight> list = flightDao.getFlight();
		return list;
	}
	public boolean deleteFlight(int fid) throws SQLException {
		boolean flag = false;
		int num = flightDao.deleteFlight(fid);
		if(num == 1){
			flag = true;
		}
		return flag;
	}
	public List<Flight> getFlightByPlace(String location,String destination) throws Exception {
		List<Flight> list = flightDao.getFlightByPlace(location,destination);
		return list;
	}
	public boolean buyTicket(int fid) throws Exception {
			boolean flag=true;
			int num=flightDao.buyTicket(fid);
			if(num!=1){
				flag=false;
			}
			return flag;
	}
	public List<Flight> getFlightByDestination(String destination) throws Exception {
		List<Flight> list = flightDao.getFlightByDestination(destination);
		return list;
	}

}
