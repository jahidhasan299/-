package com.sys.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sys.dao.UserDao;
import com.sys.pojo.User;
import com.sys.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;
	
	public boolean addUser(User user) throws Exception {
		boolean flag = true;
		int num = userDao.addUser(user);
		if(num != 1){
			flag = false;
		}
		return flag;
	}
	
	public User getUser(String username) throws Exception {
		User user = userDao.getUser(username);
		System.out.println("service+"+user);
		return user;
	}

	public boolean deleteUser(int uid) throws Exception {
		boolean flag = false;
		int num = userDao.deleteUser(uid);
		if(num == 1){
			flag = true;
		}
		return flag;
	}

	

	public boolean updateUser(User user) throws Exception {
		boolean flag = false;
		int num = userDao.updateUser(user);
		if(num ==1 ){
			flag = true;
		}
		return flag;
	}

	public User getUserByCardid(String cardid) throws Exception {
		User user = userDao.getUserByCardid(cardid);
		return user;
	}

	public User getUserByName(String username) throws Exception {
		User user = userDao.getUserByName(username);
		return user;
	}

	public User getPassword(String username, String cardid) throws Exception {
		User user = userDao.getPassword(username,cardid);
		return user;
		
}
}