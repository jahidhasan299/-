package com.sys.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sys.dao.TicketDao;
import com.sys.pojo.Ticket;
import com.sys.service.TicketService;
@Service
public class TicketServiceImpl implements TicketService {
	@Autowired
	private TicketDao ticketDao;
	public boolean Ticket(Ticket ticket) throws Exception {
		boolean flag=true;
		int num=ticketDao.Ticket(ticket);
		if(num!=1){
			flag=false;
		}
		return flag;
	}
	public List<Ticket> getTicketByUsername(String username) throws Exception {
		List<Ticket> ticket = ticketDao.getTicketByUsername(username);
		return ticket;
	}
	public boolean delTicketById(int fid) throws Exception {
		boolean flag = false;
		int num = ticketDao.delTicketById(fid);
		if(num == 1){
			flag = true;
		}
		return flag;
		
	}
}
