package com.sys.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sys.dao.ManagerDao;
import com.sys.pojo.Manager;
import com.sys.service.ManagerService;

@Service
public class ManagerServiceImpl implements ManagerService {
	@Autowired
	private ManagerDao managerDao;
	public Manager getManager(String managername) throws Exception {
		Manager manager = managerDao.getManager(managername);
		System.out.println("service+"+manager);
		return manager;
	}
	public boolean updateManager(Manager manager) throws Exception {
		boolean flag = false;
		int num =  managerDao.updateManager( manager);
		if(num ==1 ){
			flag = true;
		}
		return flag;
	}
	public Manager getPasswordM(String managername, String cardid) throws Exception {
		Manager manager = managerDao.getPasswordM(managername,cardid);
		return manager;
	}
}
