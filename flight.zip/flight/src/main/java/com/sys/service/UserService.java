package com.sys.service;

import com.sys.pojo.User;

public interface UserService {
	public boolean addUser(User user) throws Exception;
	public User getUser(String username) throws Exception;
	public boolean deleteUser(int uid) throws Exception;
	public boolean updateUser(User user) throws Exception;
	public User getUserByCardid(String cardid) throws Exception;
	public User getUserByName(String username)throws Exception;
	public User getPassword(String username,String cardid) throws Exception;
}
