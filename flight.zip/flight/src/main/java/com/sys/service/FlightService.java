package com.sys.service;

import java.util.List;

import com.sys.pojo.Flight;

public interface FlightService {
	public boolean addFlight(Flight flight) throws Exception;
	public List<Flight> getFlight() throws Exception;
	public boolean deleteFlight(int fid) throws Exception;
	public List<Flight> getFlightByPlace(String location, String destination) throws Exception;
	public boolean buyTicket(int fid) throws Exception;
	public List<Flight> getFlightByDestination(String destination) throws Exception;
}
