package com.sys.service;

import com.sys.pojo.Manager;

public interface ManagerService {
	public Manager getManager(String managername) throws Exception;
	public boolean updateManager(Manager manager) throws Exception;
	public Manager getPasswordM(String managername,String cardid) throws Exception;
}
