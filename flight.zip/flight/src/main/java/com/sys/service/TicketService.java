package com.sys.service;
import java.util.List;

import com.sys.pojo.Ticket;
public interface TicketService {
	public boolean Ticket(Ticket ticket) throws Exception;
	public List<Ticket> getTicketByUsername(String username) throws Exception;
	public boolean delTicketById(int fid) throws Exception;
}
